<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $table = 'tbl_employee';
    public $timestamps = false;
    
    public function getDepartment()
    {
        return $this->hasOne('App\Department','id','i_department_id');
    }
}