<?php
namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use App\Employee;
use App\Department;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use DB;


class EmployeeController extends Controller
{
    /**
     * Show the profile for the given user.
     *
     * @param  int  $id
     * @return View
     */
    public function index()
    {
        $resEmployee = Employee::query();
        $max_salary = DB::select('select tbl_employee.salary as salary_max, tbl_department.name as dept_name, tbl_employee.name as emp_name from tbl_employee inner join tbl_department on tbl_department.id = tbl_employee.i_department_id where tbl_employee.salary in(SELECT MAX(tbl_employee.salary) as salary from tbl_employee group by tbl_employee.i_department_id)');               
        
        
        $no_department = DB::table('tbl_employee')            
            ->select('tbl_employee.*')
            ->where('i_department_id', 0)            
            ->get();
        
        
        $min_age = DB::select('select TIMESTAMPDIFF(YEAR, dob, CURDATE()) as dob, tbl_department.name as dept_name, tbl_employee.name as emp_name from tbl_employee inner join tbl_department on tbl_department.id = tbl_employee.i_department_id having dob in(SELECT MIN(TIMESTAMPDIFF(YEAR, dob, CURDATE())) as dob from tbl_employee group by tbl_employee.i_department_id)');
        
        return view('employee.index', array('max_salary'=>$max_salary,'no_dept_emp'=>$no_department->toArray(),'min_age'=>$min_age));
        
        
    }
    public function employee_ajax(Request $request,$page = 1){
        $arrEmployee = array();
        
        Paginator::currentPageResolver(function () use ($page) {
            return $page;
        });

        $resEmployee = Employee::query();
        $resEmployee->with('getDepartment');
        $resEmployee->where('status','=',ACTIVE_STATUS);
        $arrEmployee = $resEmployee->paginate(PER_PAGE_RECORD);        
        return View("employee.emp_ajax",array('pageData'=>$arrEmployee));
    }
    public function add(Request $request, $id = 0){
        $arrEmpDetail = array();
        if($id > 0){
            $arrEmpDetail = Employee::find($id)->toArray();
        }
        else
        {
            $arrEmpDetail['name'] = '';
            $arrEmpDetail['i_department_id'] = 1;
            $arrEmpDetail['dob'] = '';
            $arrEmpDetail['phone'] = '';
            $arrEmpDetail['photo'] = '';
            $arrEmpDetail['email'] = '';
            $arrEmpDetail['salary'] = '';
        }
        $arrDepartment = array();
        $resDepartment = Department::query();
        $resDepartment->where('status','=',ACTIVE_STATUS);
        $arrDepartment = $resDepartment->get()->toArray();
        
        $arrEmpDetail['id'] = $id;
        return View('employee.add',array('data'=>$arrEmpDetail,'departments'=>$arrDepartment));
    }
    public function saveEmployee(Request $request){
        $arrData = $request->all();
        
        if($arrData['id'] > 0){
            $arrEmp = Employee::find($arrData['id']);
        }
        else{
            $arrEmp = new Employee();
        }
        //save Photo    
        
        if ($request->hasFile('photo')) {
            if(file_exists(public_path()."/uploads/".$arrEmp['photo']) && $arrEmp['photo']!= ''){
                unlink(public_path()."/uploads/".$arrEmp['photo']);
            }
            $cover = $request->file('photo');            
            $extension = $cover->getClientOriginalExtension();
            $images = $request->photo->getClientOriginalName();
            $images = time().'_'.$images;
            Storage::disk('public')->put($images,  File::get($cover));            
            $arrEmp->photo = $images;
        }        
        $arrEmp->i_department_id = $arrData['i_department_id'];
        $arrEmp->name = $arrData['name'];
        $arrEmp->dob = date('Y-m-d',strtotime($arrData['dob']));
        $arrEmp->phone = $arrData['phone'];
        $arrEmp->email = $arrData['email'];
        $arrEmp->salary = $arrData['salary'];
        $arrEmp->save();
        return redirect('');
        
    }
    public function delete(Request $request, $id = 0){
        $arrEmpDetail = Employee::find($id);
        if(empty($arrEmpDetail))
        {
            return redirect('');
        }
        $arrEmpDetail->status = 2;
        $arrEmpDetail->save();
        return redirect('');
    }
}