<?php
define('SITE_URL','http://localhost/emp_mgmt/');
define('ACTIVE_STATUS',1);
define('PER_PAGE_RECORD',5);
function pr($arr = array()){
    echo "<pre>";
    print_r($arr);
    echo "</pre>";
    return $arr;
}