$(document).ready(function(){
    $(".dv_page_data").load(SITE_URL+"get_employee_ajax", function(data){
        
    });
    $("body").on("click",".pagination a",function(){
        
        var this_data = $(this);
        var page_number = this_data[0].innerHTML;
        $.get(SITE_URL+"get_employee_ajax/"+page_number,function(data){
            $(".dv_page_data").html(data);
        });
        return false;
    });
});