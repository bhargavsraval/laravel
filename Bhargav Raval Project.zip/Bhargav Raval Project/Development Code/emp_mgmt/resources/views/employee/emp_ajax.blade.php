@if (count($pageData) > 0)
<table class="table">
    <tr>
        <th>Name</th>
        <th>Department</th>
        <th>DOB</th>
        <th>Phone Number</th>
        <th>Email</th>
        <th>Salary</th>
        <th>photo</th>
        <th>Action</th>
    </tr>
    @foreach ($pageData as $emp)
    <tr>
        <td>{{ $emp['name'] }}</td>
        <td>{{ $emp['getDepartment']['name'] }}</td>
        <td>{{ date('d-m-Y',(strtotime($emp['dob']))) }}</td>
        <td>{{ $emp['phone'] }}</td>
        <td>{{ $emp['email'] }}</td>
        <td>{{ $emp['salary'] }}</td>
        <td>
            @if ($emp['photo'] != "")
            <img src="{{ SITE_URL.'public/uploads/'.$emp['photo'] }}" width="60" height="60"/>
            @else
            NONE
            @endif
        </td>
        <td><a href="{{ SITE_URL }}edit/{{ $emp['id']}}">Edit</a> || <a href="{{ SITE_URL }}delete/{{ $emp['id']}}">Delete</a></td>
    </tr>
    @endforeach
</table>
<div class="pagination">
{{ $pageData->links() }}
</div>
@else
No Record Found
@endif
