@extends('layout.default')

@section('content')
<h3>Employee List</h3>
<div class="form-group">
    <a class="btn btn-primary mb-10 clearfix" href="{{ SITE_URL.'employee_add'}}">Add Employee</a>
</div>


<div class="dv_loading hide">Loading....</div>
<div class="dv_page_data">Data</div>

<h3>Statistics</h3>
<br/>
<h2>1.Department wise highest salary of employees.</h2>
<br/>
@if (count($max_salary) > 0)
<table class="table">
    <tr>
        <th>Name</th>
        <th>Department</th>     
        <th>Salary</th>
    </tr>
    @foreach ($max_salary as $emp_salary)
    <tr>
        <td>{{ $emp_salary->emp_name }}</td>
        <td>{{ $emp_salary->dept_name }}</td>        
        <td>{{ $emp_salary->salary_max }}</td>
    </tr>
   @endforeach
   @else
    No Record Found
   @endif
</table> 
   
<h2>2. List down employees who are not belongs to any department.</h2>
<br/>
@if (count($no_dept_emp) > 0)
<table class="table">
    <tr>
        <th>Name</th>        
    </tr>
    @foreach ($no_dept_emp as $emp)
    <tr>
        <td>{{ $emp->name }}</td>
    </tr>
   @endforeach
   @else
    No Record Found
   @endif   
</table>

<br/>

<h2>3.Find the name and age of the youngest employee in each department.</h2>
<br/>
@if (count($min_age) > 0)
<table class="table">
    <tr>
        <th>Department Name</th>       
        <th>Employee Name</th>       
        <th>Age</th>
    </tr>
    @foreach ($min_age as $emp)
    <tr>
        <td>{{ $emp->dept_name }}</td>        
        <td>{{ $emp->emp_name }}</td> 
        <td>{{ $emp->dob }}</td> 
    </tr>
   @endforeach
   @else
    No Record Found
   @endif   
</table>
@endsection
