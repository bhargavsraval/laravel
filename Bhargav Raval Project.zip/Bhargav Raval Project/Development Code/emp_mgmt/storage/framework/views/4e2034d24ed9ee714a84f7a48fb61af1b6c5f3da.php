<html>
    <head>
        <title>Employee Management</title>
        <script type="text/javascript" src="<?php echo e(SITE_URL); ?>public/js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo e(SITE_URL); ?>public/js/script.js"></script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        <script>
            var SITE_URL = "<?php echo e(SITE_URL); ?>";
        </script>
        <style>
            .hide{
                display: none;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html>