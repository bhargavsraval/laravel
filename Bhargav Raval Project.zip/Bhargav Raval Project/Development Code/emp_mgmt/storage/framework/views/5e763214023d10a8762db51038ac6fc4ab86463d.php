<?php if(count($pageData) > 0): ?>
<table>
    <tr>
        <th>Name</th>
        <th>Department</th>
        <th></th>
    </tr>
    <?php $__currentLoopData = $pageData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($emp['name']); ?></td>
        <td><?php echo e($emp['getDepartment']['name']); ?></td>
        <td><a href="<?php echo e(SITE_URL); ?>edit/<?php echo e($emp['id']); ?>">Edit</a><a href="<?php echo e(SITE_URL); ?>delete/<?php echo e($emp['id']); ?>">Delete</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<div class="pagination">
<?php echo e($pageData->links()); ?>

</div>
<?php else: ?>
No Record Found
<?php endif; ?>
