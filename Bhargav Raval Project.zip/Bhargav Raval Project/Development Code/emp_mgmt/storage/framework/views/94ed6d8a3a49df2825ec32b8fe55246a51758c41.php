<?php $__env->startSection('content'); ?>
<h3>Add Employee </h3>
<form id="frmAdd" name="frmAdd" method="post" action="<?php echo e(SITE_URL); ?>saveEmployee"  enctype="multipart/form-data" novalidate="novalidate" >
    <input type="hidden" id="id" name="id" value="<?php echo e($data['id']); ?>"/>
    <div>
        <label>Department</label>
        <select id="i_department_id" name="i_department_id" required>
            <option value="">Select Department</option>
            <?php if(count($departments) > 0): ?>
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($dept['id'] == $data['i_department_id'] ): ?>
                    <option selected="selected" value="<?php echo e($dept['id']); ?>"><?php echo e($dept['name']); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($dept['id']); ?>"><?php echo e($dept['name']); ?></option>
                <?php endif; ?>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
        </select>
    </div>
    <div>
        <label>Name</label>
        <input type="text" id="name" name="name" value="<?php echo e($data['name']); ?>" required />
    </div>
    <div>
        <input type="submit" value="Save"/>
    </div>
</form>
<script>
    
    $().ready(function() {
        // validate the comment form when it is submitted
        $("#frmAdd").validate();

        // validate signup form on keyup and submit
        $("#frmAdd").validate({
                rules: {
                name: "required"
        },
        messages: {
                name: "Please enter your firstname"
        }
        });

        
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>