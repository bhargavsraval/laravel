<?php $__env->startSection('content'); ?>
<h3>Employee List</h3>
<div class="form-group">
    <a class="btn btn-primary mb-10 clearfix" href="<?php echo e(SITE_URL.'employee_add'); ?>">Add Employee</a>
</div>


<div class="dv_loading hide">Loading....</div>
<div class="dv_page_data">Data</div>

<h3>Statistics</h3>
<br/>
<h2>1.Department wise highest salary of employees.</h2>
<br/>
<?php if(count($max_salary) > 0): ?>
<table class="table">
    <tr>
        <th>Name</th>
        <th>Department</th>     
        <th>Salary</th>
    </tr>
    <?php $__currentLoopData = $max_salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp_salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($emp_salary->emp_name); ?></td>
        <td><?php echo e($emp_salary->dept_name); ?></td>        
        <td><?php echo e($emp_salary->salary_max); ?></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php else: ?>
    No Record Found
   <?php endif; ?>
</table> 
   
<h2>2. List down employees who are not belongs to any department.</h2>
<br/>
<?php if(count($no_dept_emp) > 0): ?>
<table class="table">
    <tr>
        <th>Name</th>        
    </tr>
    <?php $__currentLoopData = $no_dept_emp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($emp->name); ?></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php else: ?>
    No Record Found
   <?php endif; ?>   
</table>

<br/>

<h2>3.Find the name and age of the youngest employee in each department.</h2>
<br/>
<?php if(count($min_age) > 0): ?>
<table class="table">
    <tr>
        <th>Department Name</th>       
        <th>Employee Name</th>       
        <th>Age</th>
    </tr>
    <?php $__currentLoopData = $min_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($emp->dept_name); ?></td>        
        <td><?php echo e($emp->emp_name); ?></td> 
        <td><?php echo e($emp->dob); ?></td> 
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php else: ?>
    No Record Found
   <?php endif; ?>   
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>