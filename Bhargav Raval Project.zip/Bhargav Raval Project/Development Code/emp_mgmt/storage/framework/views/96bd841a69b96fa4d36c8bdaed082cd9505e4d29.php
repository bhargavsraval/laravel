<html>
    <head>
        <title>Employee Management</title>
        <script type="text/javascript" src="<?php echo e(SITE_URL); ?>public/js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo e(SITE_URL); ?>public/js/script.js"></script>
        <script src="<?php echo e(SITE_URL); ?>public/js/jquery.validate.min.js"></script>
        <script src="<?php echo e(SITE_URL); ?>public/js/jquery-ui.js"></script>
        <script src="<?php echo e(SITE_URL); ?>public/js/additional-methods.js"></script>
        <link rel="stylesheet" href="<?php echo e(SITE_URL); ?>public/css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo e(SITE_URL); ?>public/css/bootstrap.min.css">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <script>
            var SITE_URL = "<?php echo e(SITE_URL); ?>";
        </script>
        <style>
            .hide{
                display: none;
            }
            .border,.border tr,.border td,.border th{
                border: solid 1px;
            }            
        </style>
    </head>
    <body>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html>