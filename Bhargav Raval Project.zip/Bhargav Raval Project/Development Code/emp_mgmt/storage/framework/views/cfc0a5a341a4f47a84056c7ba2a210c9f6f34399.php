<?php $__env->startSection('content'); ?>
<div class="container">
<h3>Add Employee </h3>
<form  id="frmAdd" name="frmAdd" method="post" action="<?php echo e(SITE_URL); ?>saveEmployee"  enctype="multipart/form-data" novalidate="novalidate" >
    <div class="form-group">
        <input type="hidden" id="id" name="id" value="<?php echo e($data['id']); ?>"/>
        <div  class="form-group">
            <label>Department</label>
            <select id="i_department_id" class="form-control" name="i_department_id">
                <option value="0">Select Department</option>
                <?php if(count($departments) > 0): ?>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($dept['id'] == $data['i_department_id'] ): ?>
                        <option selected="selected" value="<?php echo e($dept['id']); ?>"><?php echo e($dept['name']); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($dept['id']); ?>"><?php echo e($dept['name']); ?></option>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Name *</label>
            <input type="text" id="name" name="name" class="form-control" value="<?php echo e($data['name']); ?>" required />
        </div>
        <div class="form-group">
            <label>DOB *</label>
            <input type="text" id="dob" name="dob" class="form-control" value="<?php echo e($data['dob']); ?>" required readonly>
        </div>
        <div class="form-group">
            <label>Phone Number *</label>
            <input type="text" id="phone" name="phone"  class="form-control"  value="<?php echo e($data['phone']); ?>"  required>
        </div>

        <div class="form-group">
            <label>Photo *</label>
            <?php if($data['photo'] != ""): ?>
            <img src="<?php echo e(SITE_URL.'public/uploads/'.$data['photo']); ?>" width="60" height="60" class="border"/>
            <input type="file" id="photo" name="photo" accept="image/*" class="form-control">
            <?php else: ?>
            <input type="file" id="photo" name="photo" required accept="image/*" class="form-control">
            <?php endif; ?>
            
        </div>

        <div class="form-group">
            <label>Email *</label>
            <input type="text" id="email" name="email" value="<?php echo e($data['email']); ?>" required class="form-control">
        </div>

        <div class="form-group">
            <label>Salary *</label>
            <input type="text" id="salary" name="salary"  value="<?php echo e($data['salary']); ?>"  required class="form-control">
        </div>   
        <div>
            <input type="submit" value="Save"/>
        </div>
        
    </div>
    
</form>
</div>
<script>
    
    $().ready(function() {
        // validate the comment form when it is submitted
        //$("#frmAdd").validate();

        // validate signup form on keyup and submit
        $("#frmAdd").validate({
            rules: {
             salary: {
                required: true,
                salary: true
            },
            email: {
                required: true,
                email: true
            },
            phone: {
                required  : true,
                phonenumber: true,  // <-- no such method called "matches"!
                minlength:10,
                maxlength:10
            }
        },
               
        messages: {
                salary: "Please enter valid salary",
                photo: "select valid photo type"
        }
        });
        
        jQuery.validator.addMethod("salary", function(value, element) {
        return this.optional(element) || /^\d{0,7}(\.\d{0,2})?$/i.test(value);
        }, "You must include two decimal places");
        
        jQuery.validator.addMethod("phonenumber", function(value, element) {
        return this.optional(element) || /\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/.test(value);
        }, "enter valid phone number");

        
    });
    $( function() {
    $( "#dob" ).datepicker(
    {
        changeMonth: true,
        changeYear: true,
        yearRange: "-35:+0"
    });
    
  } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>