<?php $__env->startSection('content'); ?>
<h3>Employee List</h3>
<a href="<?php echo e(SITE_URL.'employee_add'); ?>">Add Employee</a>
<div class="dv_loading hide">Loading....</div>
<div class="dv_page_data">Data</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>