-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 11, 2019 at 07:51 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emp_mgmt`
--
CREATE DATABASE IF NOT EXISTS `emp_mgmt` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `emp_mgmt`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_department`
--

DROP TABLE IF EXISTS `tbl_department`;
CREATE TABLE `tbl_department` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1 => Active, 2 => Deleted',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_department`
--

INSERT INTO `tbl_department` (`id`, `name`, `status`, `created`) VALUES
(1, '.Net', 1, '2019-02-08 11:27:38'),
(2, 'Sales', 1, '2019-02-08 11:27:38'),
(3, 'Support', 1, '2019-02-08 11:27:53'),
(4, 'PHP', 1, '2019-02-08 11:27:53'),
(5, 'QA', 1, '2019-02-08 11:28:17'),
(6, 'Android', 1, '2019-02-08 11:28:17');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

DROP TABLE IF EXISTS `tbl_employee`;
CREATE TABLE `tbl_employee` (
  `id` bigint(20) NOT NULL,
  `i_department_id` bigint(20) DEFAULT NULL COMMENT 'FK to tbl_department',
  `name` varchar(50) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `status` int(11) DEFAULT '1' COMMENT '1 = > Active, 2 => Deleted',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `i_department_id`, `name`, `dob`, `phone`, `photo`, `email`, `salary`, `status`, `created`, `modified`) VALUES
(1, 1, 'rITESH', '1984-02-01', '9898989898', '1549865453_4.png', 'TEST@TEST.COM', '1000.00', 1, '2019-02-08 19:23:01', '0000-00-00 00:00:00'),
(2, 1, 'Parth', '1986-02-01', '1234567890', '1549865467_1.png', 'test@test1.com', '100000.00', 1, '2019-02-08 19:24:10', '0000-00-00 00:00:00'),
(3, 4, 'Jignesh', '1987-02-02', '1234567890', '1549865423_3.png', 'jignesh@test.com', '140000.00', 1, '2019-02-11 10:31:38', '0000-00-00 00:00:00'),
(4, 0, 'Jaimin', '1986-02-01', '1234567890', '1549865416_2.jpeg', 'test@test.com', '60004.00', 1, '2019-02-11 11:18:06', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_department`
--
ALTER TABLE `tbl_department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_department`
--
ALTER TABLE `tbl_department`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
